# MySell Auth – Roblox Script Key Store

A clean SellAuth-style website for selling Roblox script keys with **instant email delivery**.

## Features

- Modern dark storefront with product cards
- Instant unique key generation + assignment
- Automatic email delivery of the key (Nodemailer)
- Admin dashboard (orders, stock, generate keys)
- SQLite database (zero config)
- Ready for real payments (Stripe / crypto later)

## Quick Start

```bash
cd mysell-auth
npm install
cp .env.example .env
# edit .env with your SMTP + admin password
npm start
```

Open http://localhost:3000

**Admin:** http://localhost:3000/admin  
Default login: `admin` / `supersecret123` (change in `.env`)

## Email Setup (important)

For real key emails, fill these in `.env`:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@gmail.com
SMTP_PASS=your-app-password   # Gmail → App Passwords
EMAIL_FROM="Your Script <noreply@yourdomain.com>"
```

Without SMTP the site still works – keys are shown on the success page and logged to the console (demo mode).

## How it works

1. Buyer picks a plan → enters email
2. Mock payment succeeds (replace with Stripe later)
3. System assigns a unique key from stock (or generates one)
4. Key is emailed instantly + shown on the success page
5. You can manage stock & view orders in the admin panel

## Adding real payments later

- Stripe Checkout Session or Payment Intent
- SellAuth / Sellix webhooks
- Crypto (NOWPayments, Coinbase Commerce, etc.)

Just replace the mock `/checkout` route with a real payment flow and call `assignKey` + `sendKeyEmail` on the webhook success.

## File structure

```
mysell-auth/
├── server.js          # Express app
├── utils/
│   ├── db.js          # SQLite + schema
│   ├── keys.js        # Key generation & assignment
│   └── email.js       # Nodemailer sender
├── views/             # EJS templates
├── public/style.css
├── .env.example
└── data.db            # created automatically
```

## License

MIT – use it however you want.
